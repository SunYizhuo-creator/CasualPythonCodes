import pyautogui
import time
import pyperclip
import requests
import json
# 全局设置：放慢操作速度，避免失控
pyautogui.PAUSE = 0.8
pyautogui.FAILSAFE = True

# ========== 替换为你的实际参数 ==========
CONTACT_NAME = "每天都在看日落"  # 联系人名称
INPUT_BOX_X = 499  # 步骤1获取的输入框x坐标
INPUT_BOX_Y = 946  # 步骤1获取的输入框y坐标

SEND_MSG = "这是一条自动发送的测试消息"

def open_and_activate_wechat():
    """打开并激活微信窗口（确保获得焦点）"""
    # 1. 回到桌面，避免窗口遮挡
    pyautogui.hotkey("win", "d")
    time.sleep(1)
    # 2. 唤起微信
    pyautogui.hotkey("alt", "ctrl", "w")
    time.sleep(3)  # 给足加载时间（新版微信启动慢）
    

import pyperclip
# 定义一个查询联系人的函数，参数为name
def chatWho(name):
    # 使用hotkey函数，操作按键"command","f"，打开搜索
    pyautogui.hotkey("ctrl","f")
    # 使用pyperclip模块中的copy函数，复制微信号name到剪贴板
    pyperclip.copy(name)
    # 使用hotkey函数，操作按键"command", "v"，粘贴微信号
    pyautogui.hotkey("ctrl", "v")
    # 使用hotkey函数，操作按键"return"，确认搜索
    pyautogui.hotkey("enter")
def send_message(msg):
    """精准粘贴并发送消息"""
    # 1. 点击输入框，强制激活（核心！）
    pyautogui.click(INPUT_BOX_X, INPUT_BOX_Y)
    time.sleep(1)
    # 2. 清空输入框（可选）
    pyautogui.hotkey("ctrl", "a", "backspace")
    time.sleep(0.5)
    # 3. 复制消息到剪贴板（双重确认）
    pyperclip.copy(msg)
    time.sleep(1)  # 等待剪贴板同步
    # 4. 粘贴（如果Ctrl+V无效，改用模拟输入）
    try:
        pyautogui.hotkey("ctrl", "v")
    except:
        # 备用方案：直接输入（绕过剪贴板风控）
        pyautogui.typewrite(msg)
    time.sleep(1)
    # 5. 发送消息（双保险：先试Ctrl+Enter，再试Enter）
    
    pyautogui.hotkey("enter")

def get_hitokoto():
    # 请求一言API，指定返回纯文本
    url = "https://v1.hitokoto.cn/?c=a&encode=text"
    # c=a 表示动漫类，可选：c=b（名言）、c=c（古诗词）、c=d（网络）
    try:
        return requests.get(url, timeout=5).text
    except:
        return "愿你遍历山河，觉得人间值得。"  # 兜底句子
    
def get_daily_sentence():
    # 可选接口1：每日诗词（推荐）
    url = "https://v1.jinrishici.com/rensheng.txt"
    # 可选接口2：每日一句名言
    # url = "https://api.ooopn.com/mingyan/api.php?type=shuowen"
    
    try:
        response = requests.get(url, timeout=5)
        response.encoding = "utf-8"  # 确保中文不乱码
        return response.text.strip()  # 返回纯文本句子
    except Exception as e:
        return f"获取失败：{e}"

def get_zen_quote():
    url = "https://zenquotes.io/api/random"
    try:
        data = requests.get(url, timeout=5).json()[0]
        return f"{data['q']}\n— {data['a']}"
    except:
        return "Dream big and dare to fail.\n— Norman Vaughan"    

message = ""
message+="今日一言："
message+=get_hitokoto()
message+="\n"
message+="今日一句："
message+=get_daily_sentence()
message+="\n"
message+="Quotation Today:\n"
message+=get_zen_quote()

# 主流程
if __name__ == "__main__":
    open_and_activate_wechat()
    chatWho(CONTACT_NAME)
    send_message(message)
    print("消息发送完成！")