import os
import warnings
warnings.filterwarnings("ignore")

# 国内网络建议加镜像
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"

import whisperx

# ===================== 你的设置 =====================
FOLDER = r'C:\Users\Administrator\OneDrive\家庭录音'
LANGUAGE = "zh"
MODEL = "medium"          # 推荐 medium；如需更高精度可改成 "large-v3"
DEVICE = "cpu"
COMPUTE_TYPE = "int8"     # CPU 更稳
BATCH_SIZE = 1
# ====================================================

audio_formats = ('.mp3', '.wav', '.m4a', '.flac', '.wma', '.aac', '.ogg')

def format_time(seconds):
    """把秒数转换成 HH:MM:SS 格式"""
    if seconds is None:
        return "00:00:00"

    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"

def main():
    if not os.path.exists(FOLDER):
        print(f"❌ 文件夹不存在：{FOLDER}")
        return

    print("正在加载语音模型（第一次会自动下载，稍等）...")
    print(f"模型：{MODEL} | 设备：{DEVICE} | 计算类型：{COMPUTE_TYPE}")

    model = whisperx.load_model(
        MODEL,
        DEVICE,
        language=LANGUAGE,
        compute_type=COMPUTE_TYPE
    )

    files = os.listdir(FOLDER)
    audio_files = [f for f in files if f.lower().endswith(audio_formats)]

    if not audio_files:
        print("❌ 没有找到可处理的音频文件。")
        return

    print(f"共找到 {len(audio_files)} 个音频文件，开始处理...")

    success_count = 0
    fail_count = 0

    for filename in audio_files:
        audio_path = os.path.join(FOLDER, filename)

        try:
            print(f"\n{'='*60}")
            print(f"正在处理：{filename}")

            # 加载音频
            audio = whisperx.load_audio(audio_path)

            # 转写
            result = model.transcribe(audio, batch_size=BATCH_SIZE)

            # 保存带时间戳的文本
            txt_file = audio_path + ".时间戳.txt"
            with open(txt_file, "w", encoding="utf-8") as f:
                for seg in result["segments"]:
                    start_time = format_time(seg.get("start", 0))
                    end_time = format_time(seg.get("end", 0))
                    text = seg.get("text", "").strip()

                    if text:
                        line = f"[{start_time} - {end_time}] {text}"
                        f.write(line + "\n")
                        print(line)

            print(f"✅ 已保存：{txt_file}")
            success_count += 1

        except Exception as e:
            print(f"❌ 处理失败：{filename}")
            print(f"错误信息：{str(e)}")
            fail_count += 1

    print(f"\n{'='*60}")
    print("🎉 全部处理结束！")
    print(f"成功：{success_count} 个")
    print(f"失败：{fail_count} 个")

if __name__ == "__main__":
    main()
